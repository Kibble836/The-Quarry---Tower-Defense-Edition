﻿Public Class frmHelp

    Private Sub btnMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMenu.Click
        frmMenu.Show()
    End Sub
End Class